module omnirouter

go 1.23.0

require (
	modernc.org/sqlite v1.34.5
	modernc.org/libc v1.55.3 // indirect: keep aligned with modernc.org/sqlite v1.34.5
	modernc.org/mathutil v1.6.0 // indirect
	modernc.org/memory v1.8.0 // indirect
)
